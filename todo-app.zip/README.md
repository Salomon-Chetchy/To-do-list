# To-Do List App

A simple to-do list built with plain HTML, CSS and JavaScript. No install needed.

## Features
- Add, complete and delete tasks
- Filter: All / Active / Done
- Clear completed tasks
- Tasks are saved in your browser (localStorage)

## Run it
Unzip the folder and open `index.html` in your browser.

## Unzip

**Linux / macOS / Git Bash:**
```bash
unzip todo-app.zip -d todo-app
cd todo-app
```

**Windows (PowerShell):**
```powershell
Expand-Archive todo-app.zip -DestinationPath todo-app
cd todo-app
```

## Put it on GitHub

1. Create an empty repository on github.com (for example `todo-app`), without a README.
2. Then run:

```bash
git init
git add .
git commit -m "Initial commit: to-do list app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/todo-app.git
git push -u origin main
```

## Optional: host it for free
In your repo go to **Settings > Pages**, choose branch `main` and folder `/ (root)`, then save. Your app will be live at `https://YOUR-USERNAME.github.io/todo-app/`.
